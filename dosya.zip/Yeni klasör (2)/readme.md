# 🛡️ RZai - Local Document Intelligence & RAG Platform

![RZai Dashboard](https://raw.githubusercontent.com/username/repository/main/assets/preview.png)

**RZai**, kurumların ve bireysel kullanıcıların sözleşmelerini, teknik dokümanlarını ve PDF dosyalarını yerel bilgisayarlarında **%100 gizlilik** ile analiz etmesini sağlayan modern bir **RAG (Retrieval-Augmented Generation)** platformudur.

Ollama altyapısını kullanarak verilerin dışarı çıkmasını engeller, hiçbir API anahtarına veya ödemeye ihtiyaç duymaz.

---

## 🌟 Öne Çıkan Özellikler

* 🔒 **%100 Yerel Veri Gizliliği:** Tüm analizler bilgisayarınızda gerçekleşir, dış sunuculara veri gönderilmez.
* 💸 **Sınırsız ve Ücretsiz:** API limiti veya kota kısıtlaması yoktur.
* 🛡️ **Cyber-SaaS Arayüzü:** Modern, dark-mode odaklı kullanıcı deneyimi.
* ⚡ **Hızlı Vektör Arama:** ChromaDB ve HuggingFace embedding modelleri ile doküman içi anlamsal arama.

---

## 🚀 Hızlı Başlangıç

### 1. Ön Gereksinim (Ollama Kurulumu)
Bilgisayarınızda [Ollama](https://ollama.com/)'nın yüklü olması gerekmektedir. Yükledikten sonra terminalden istediğiniz modeli indirin:
```bash
ollama run llama3