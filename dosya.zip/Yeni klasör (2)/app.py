import os
import tempfile
import time
import streamlit as st

# Sayfa Yapılandırması
st.set_page_config(
    page_title="RZai | Secure Document Intelligence Platform",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Dark Cyber-SaaS Tema CSS
st.markdown("""
<style>
    .stApp { background-color: #0d1117; color: #c9d1d9; }
    section[data-testid="stSidebar"] { background-color: #161b22; border-right: 1px solid #30363d; }
    .logo-container { display: flex; align-items: center; gap: 12px; padding: 10px 0 20px 0; border-bottom: 1px solid #30363d; margin-bottom: 20px; }
    .logo-text { font-size: 1.8rem; font-weight: 800; letter-spacing: 1px; background: linear-gradient(135deg, #58a6ff 0%, #3fb950 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
    .rzai-card { background-color: #161b22; border: 1px solid #30363d; border-radius: 8px; padding: 16px; margin-bottom: 16px; }
    .stButton>button { width: 100%; background: linear-gradient(180deg, #238636 0%, #2ea043 100%); color: #ffffff; border: 1px solid rgba(240,246,252,0.1); border-radius: 6px; padding: 0.65rem 1rem; font-weight: 700; }
    .stButton>button:hover { background: linear-gradient(180deg, #2ea043 0%, #3fb950 100%); box-shadow: 0 0 10px rgba(46, 160, 67, 0.4); }
    .status-badge { display: inline-block; padding: 4px 10px; border-radius: 12px; font-size: 0.75rem; font-weight: 700; background-color: rgba(57, 211, 83, 0.15); color: #39d353; border: 1px solid rgba(57, 211, 83, 0.3); }
</style>
""", unsafe_allow_html=True)

# Sol Menü (Sidebar)
with st.sidebar:
    st.markdown("""
    <div class="logo-container">
        <svg width="38" height="38" viewBox="0 0 24 24" fill="none"><path d="M12 2L3 7V12C3 17.55 6.84 22.74 12 24C17.16 22.74 21 17.55 21 12V7L12 2Z" fill="#161b22" stroke="#58a6ff" stroke-width="2"/><path d="M12 6L7 9V12C7 15.31 9.14 18.39 12 19.33C14.86 18.39 17 15.31 17 12V9L12 6Z" fill="url(#paint0_linear)"/><defs><linearGradient id="paint0_linear" x1="7" y1="6" x2="17" y2="19.33" gradientUnits="userSpaceOnUse"><stop stop-color="#58a6ff"/><stop offset="1" stop-color="#3fb950"/></linearGradient></defs></svg>
        <span class="logo-text">RZai</span>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("### 📑 WORKSPACE")
    uploaded_file = st.file_uploader("Doküman Yükle (PDF)", type=["pdf"])
    
    st.markdown("---")
    st.markdown("### ⚙️ MOTOR DURUMU")
    st.caption("• **Engine:** Ollama Local LLM")
    st.caption("• **Model:** llama3 (or llama2 / qwen)")
    st.caption("• **API Key:** Not Required (%100 Free)")
    
    st.markdown("---")
    st.markdown("""<span class="status-badge">🟢 OLLAMA ENGINE ONLINE</span>""", unsafe_allow_html=True)

# Ana Panel
st.markdown("""
<div style="border-bottom: 1px solid #30363d; padding-bottom: 12px; margin-bottom: 20px;">
    <h2 style="margin:0; font-weight: 700;">SECURE DOCUMENT INTELLIGENCE PLATFORM (RZai v3.1)</h2>
    <span style="color: #8b949e;">LOCAL OLLAMA RAG ENGINE</span>
</div>
""", unsafe_allow_html=True)

if uploaded_file is not None:
    col_main, col_right = st.columns([2.2, 1])

    with col_main:
        st.markdown(f"""<div class="rzai-card">📊 <b>AKTİF DOKÜMAN:</b> {uploaded_file.name}</div>""", unsafe_allow_html=True)
        user_query = st.text_area("Analiz Komutu veya Soru Girin:", height=100, placeholder="Dokümandaki temel maddeleri özetle...")
        submit_btn = st.button("🚀 ANALİZİ BAŞLAT")

        if submit_btn and user_query:
            start_time = time.time()
            with st.spinner("RZai ve Ollama dokümanı analiz ediyor..."):
                try:
                    with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp_file:
                        tmp_file.write(uploaded_file.read())
                        tmp_path = tmp_file.name

                    from langchain_community.document_loaders import PyPDFLoader
                    from langchain_text_splitters import RecursiveCharacterTextSplitter
                    from langchain_chroma import Chroma
                    from langchain_community.embeddings import HuggingFaceEmbeddings
                    from langchain_community.llms import Ollama

                    # 1. Dokümanı Parçalara Bölme
                    loader = PyPDFLoader(tmp_path)
                    docs = loader.load()
                    text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
                    splits = text_splitter.split_documents(docs)

                    # 2. Vektörleştirme (Lokal HuggingFace)
                    embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
                    vectorstore = Chroma.from_documents(documents=splits, embedding=embeddings)
                    retriever = vectorstore.as_retriever(search_kwargs={"k": 2})

                    # 3. Ollama LLM Çağrısı
                    # bilgisayarında hangi model yüklüyse model="llama3" kısmını ona göre düzenleyebilirsin
                    llm = Ollama(model="llama3") 
                    
                    rel_docs = retriever.invoke(user_query)
                    context = "\n\n".join([doc.page_content for doc in rel_docs])

                    prompt = f"Sen RZai Doküman Analiz Sistemisin. Aşağıdaki bağlamı kullanarak soruyu detaylıca Türkçe yanıtla.\n\nBağlam:\n{context}\n\nSoru: {user_query}\n\nYanıt:"
                    response = llm.invoke(prompt)

                    st.markdown("### 📜 ANALİZ BULGULARI")
                    st.markdown(f"""<div style="background-color: #0d1117; border: 1px solid #30363d; padding: 12px; border-radius: 6px;">{response}</div>""", unsafe_allow_html=True)

                    if os.path.exists(tmp_path):
                        os.remove(tmp_path)

                except Exception as e:
                    st.error(f"Sistem Hatası (Ollama'nın açık olduğundan emin olun): {e}")

    with col_right:
        st.markdown("#### ⚙️ SİSTEM METRİKLERİ")
        st.markdown("""
        <div class="rzai-card" style="font-size: 0.85rem; line-height: 1.8;">
            ⚡ <b>Mode:</b> Local Hardware<br/>
            🧠 <b>LLM Engine:</b> Ollama (Local)<br/>
            🧬 <b>Embed Model:</b> HuggingFace (Local)<br/>
            🔑 <b>API Key Required:</b> NO<br/>
            🔒 <b>Privacy:</b> 100% On-Device
        </div>
        """, unsafe_allow_html=True)
else:
    st.info("Başlamak için sol taraftan bir PDF dokümanı yükleyin.")